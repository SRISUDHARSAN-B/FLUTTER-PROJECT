package com.example.electric_bill

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
